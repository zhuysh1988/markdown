package com.openshift.evg.roadshow.rest;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

/**
 *
 * Created by jmorales on 11/08/16.
 */
@ApplicationPath("/ws")
public class MLBParksApplication extends Application {
    public MLBParksApplication() {
    }
}
